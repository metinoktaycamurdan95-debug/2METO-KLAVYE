package com.metto.klavye

import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import java.util.concurrent.Executors

/** Tableti Bluetooth HID klavye olarak tanıtır ve tuş raporları gönderir. */
@SuppressLint("MissingPermission")
class HidController(private val ctx: Context, private val onState: (String) -> Unit) {
    private val adapter: BluetoothAdapter? =
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private val prefs = ctx.getSharedPreferences("hid", Context.MODE_PRIVATE)
    private var hid: BluetoothHidDevice? = null
    @Volatile private var host: BluetoothDevice? = null
    @Volatile private var registered = false
    @Volatile private var stopped = false
    private val keys = ArrayList<Int>()
    private var mods = 0
    private val downAt = HashMap<Int, Long>()
    private val pend = HashMap<Int, Runnable>()
    private var tries = 0
    private var lastRestart = 0L
    private var nkroOn = false
    private val exec = Executors.newSingleThreadExecutor()

    /** false = yazı modu (her basış kısa bir dokunuş, tuş asla takılı kalmaz), true = oyun modu (basılı tut) */
    @Volatile var hold = false
        set(v) {
            if (field != v) {
                field = v
                // mod değişince iki rapordaki basılı tuşları temizle
                q.post { keys.clear(); mods = 0; downAt.clear(); pushEmpty() }
            }
        }

    private val ht = HandlerThread("hid").also { it.start() }
    private val q = Handler(ht.looper)

    private val cb = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            this@HidController.registered = registered
            onState(if (registered) "Hazır (profil: " + profileName() + "). Telefondan eşleştir ya da cihaza bağlan" else "Kayıt başarısız")
            if (registered) { tries = 0; q.postDelayed({ autoConnect() }, 800) }
        }
        override fun onConnectionStateChanged(device: BluetoothDevice, state: Int) {
            if (state == BluetoothProfile.STATE_CONNECTED) {
                host = device
                prefs.edit().putString("last", device.address).apply()
                // Her bağlantıda temiz başla: eski basılı tuş durumu kalmasın
                q.post {
                    keys.clear(); mods = 0; downAt.clear()
                    pend.values.forEach { q.removeCallbacks(it) }; pend.clear()
                    pushEmpty()
                }
                onState("Bağlı: " + (device.name ?: device.address))
            } else if (state == BluetoothProfile.STATE_DISCONNECTED && host == device) {
                host = null
                q.post {
                    keys.clear(); mods = 0; downAt.clear()
                    pend.values.forEach { q.removeCallbacks(it) }; pend.clear()
                }
                onState("Bağlantı koptu, yeniden deneniyor…")
                tries = 0
                q.postDelayed({ autoConnect() }, 2500)
            }
        }
    }

    /** Son bağlanılan cihaza otomatik bağlan; kopunca ve Bluetooth aç-kapa sonrası da sürekli dener */
    private val autoRun = Runnable { autoConnect() }

    private fun autoConnect() {
        if (stopped) return
        q.removeCallbacks(autoRun)
        if (host != null) return
        if (!registered || hid == null) { q.postDelayed(autoRun, 3000); return }
        val addr = prefs.getString("last", null) ?: return
        val d = bonded().firstOrNull { it.address == addr } ?: return
        hid?.connect(d)
        tries++
        q.postDelayed(autoRun, if (tries < 20) 7000L else 20000L)
    }

    /** Uygulama öne gelince hemen tekrar dene */
    fun reconnectNow() { tries = 0; q.post { autoConnect() } }

    /** Bluetooth kapanıp açılınca HID kaydını baştan yap */
    private fun restart() {
        if (stopped) return
        val a = adapter
        if (a == null || !a.isEnabled) return
        lastRestart = SystemClock.uptimeMillis()
        try { hid?.unregisterApp() } catch (_: Exception) {}
        try { a.closeProfileProxy(BluetoothProfile.HID_DEVICE, hid) } catch (_: Exception) {}
        hid = null; registered = false
        // kaydın tamamen silinmesi için kısa bekle, sonra yeni tanımla kaydol
        q.postDelayed({ start() }, 800)
    }

    private val stateRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            when (i?.getIntExtra(BluetoothAdapter.EXTRA_STATE, -1)) {
                BluetoothAdapter.STATE_OFF -> {
                    registered = false; host = null; hid = null
                    q.post { keys.clear(); mods = 0; downAt.clear() }
                    onState("Bluetooth kapandı")
                }
                BluetoothAdapter.STATE_ON -> {
                    onState("Bluetooth açıldı, hazırlanıyor…")
                    q.postDelayed({ restart() }, 1500)
                }
            }
        }
    }

    init {
        try { ctx.registerReceiver(stateRx, IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED)) } catch (_: Exception) {}
    }

    fun start() {
        val a = adapter
        if (a == null || !a.isEnabled) { onState("Bluetooth kapalı"); return }
        a.getProfileProxy(ctx, object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                val h = proxy as BluetoothHidDevice
                hid = h
                val sdp = BluetoothHidDeviceAppSdpSettings(
                    "Metto Klavye", "Klavye", "Metto", subclassFor(profileNow), desc(profileNow)
                )
                if (!h.registerApp(sdp, null, null, exec, cb)) onState("Bu cihaz Bluetooth klavye modunu desteklemiyor")
            }
            override fun onServiceDisconnected(profile: Int) {
                hid = null; registered = false; host = null
                if (!stopped && SystemClock.uptimeMillis() - lastRestart > 3000) q.postDelayed({ restart() }, 1500)
            }
        }, BluetoothProfile.HID_DEVICE)
    }

    /** Telefona tanıtılan cihaz türü. Değişince telefonda tableti unutup tekrar eşleştirmek gerekir. */
    val profileNow: Int get() = prefs.getInt("profile", 0)

    private fun padOnly() = profileNow == 2 || profileNow == 4

    private fun profileName(): String = when (profileNow) {
        1 -> "klavye+ses"
        2 -> "sadece gamepad"
        3 -> "sadece klavye"
        4 -> "sadece gamepad (B)"
        else -> "tam"
    }

    private fun subclassFor(p: Int): Byte =
        if (p == 4) BluetoothHidDevice.SUBCLASS2_GAMEPAD else BluetoothHidDevice.SUBCLASS1_COMBO

    fun setProfile(p: Int) {
        prefs.edit().putInt("profile", p).apply()
        q.post { keys.clear(); mods = 0; downAt.clear(); restart() }
    }

    /** Uygulama kapanırken kaydı temizle, yoksa yeniden açınca çift kayıt olur */
    fun stop() {
        stopped = true
        try { ctx.unregisterReceiver(stateRx) } catch (_: Exception) {}
        try { hid?.unregisterApp() } catch (_: Exception) {}
        try { adapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, hid) } catch (_: Exception) {}
        q.removeCallbacksAndMessages(null)
        ht.quitSafely()
    }

    fun bonded(): List<BluetoothDevice> = adapter?.bondedDevices?.toList() ?: emptyList()

    fun connect(d: BluetoothDevice) {
        onState("Bağlanıyor: " + (d.name ?: d.address))
        hid?.connect(d)
    }

    fun key(down: Boolean, usage: Int) { q.post { apply(down, usage) } }

    /** Sayfadan gelen basılı tutma tekrarı: yazı modunda her tekrar yeni bir dokunuş */
    fun repeat(usage: Int) { q.post { if (!hold && usage < 224) tap(usage) } }

    private fun apply(down: Boolean, usage: Int) {
        val now = SystemClock.uptimeMillis()
        if (down) {
            if (usage < 224 && !hold) { tap(usage); return }
            // aynı tuşa çok hızlı tekrar basıldıysa önceki bırakmayı hemen bitir
            pend.remove(usage)?.let { q.removeCallbacks(it); release(usage) }
            downAt[usage] = now
            if (usage >= 224) mods = mods or (1 shl (usage - 224))
            else { keys.remove(usage); keys.add(usage) }
            push()
            return
        }
        if (usage < 224 && !hold) return   // yazı modunda bırakma bilgisi gerekmez
        // Çok kısa basışlar kaybolmasın: en az MIN_HOLD ms basılı kalsın
        val wait = MIN_HOLD - (now - (downAt[usage] ?: 0L))
        if (wait > 0) {
            val r = Runnable { pend.remove(usage); release(usage) }
            pend[usage] = r
            q.postDelayed(r, wait)
        } else release(usage)
    }

    private fun release(usage: Int) {
        downAt.remove(usage)
        if (usage >= 224) mods = mods and (1 shl (usage - 224)).inv()
        else keys.remove(usage)
        push()
        q.postDelayed({ push() }, 30)   // bırakma raporu kaybolursa tuş takılı kalmasın
    }

    private fun tap(usage: Int) {
        keys.remove(usage); keys.add(usage); push()
        q.postDelayed({ keys.remove(usage); push() }, 35)
        q.postDelayed({ push() }, 65)
    }

    private fun push() {
        val h = host ?: return
        if (padOnly()) return
        if (hold && profileNow == 0 && keys.size > 6) {
            // 6'dan fazla tuş: bitmap rapor (ID 3). Normalde her zaman standart rapor (ID 1) kullanılır.
            val r = ByteArray(16)
            r[0] = mods.toByte()
            for (u in keys) {
                if (u in 0..119) r[1 + u / 8] = (r[1 + u / 8].toInt() or (1 shl (u % 8))).toByte()
            }
            hid?.sendReport(h, 3, r)
            nkroOn = true
        } else {
            if (nkroOn) { hid?.sendReport(h, 3, ByteArray(16)); nkroOn = false }
            val r = ByteArray(8)
            r[0] = mods.toByte()
            for (i in 0 until minOf(6, keys.size)) r[2 + i] = keys[i].toByte()
            hid?.sendReport(h, 1, r)
        }
    }

    private fun pushEmpty() {
        val h = host ?: return
        val p = profileNow
        if (!padOnly()) hid?.sendReport(h, 1, ByteArray(8))
        if (p == 0) hid?.sendReport(h, 3, ByteArray(16))
        if (p == 0 || padOnly()) hid?.sendReport(h, 5, byteArrayOf(0, 0, 8, 128.toByte(), 128.toByte(), 128.toByte(), 128.toByte()))
    }

    private var okCnt = 0
    private var failCnt = 0

    private fun rep(h: BluetoothDevice, id: Int, d: ByteArray) {
        val ok = try { hid?.sendReport(h, id, d) ?: false } catch (_: Exception) { false }
        if (ok) okCnt++ else failCnt++
    }

    /** Gamepad: buttons 16 bit, hat 0-7 (8 = boş), lx/ly/rx/ry 0-255 */
    fun pad(buttons: Int, hat: Int, lx: Int, ly: Int, rx: Int, ry: Int) {
        q.post {
            val h = host ?: return@post
            rep(h, 5, byteArrayOf(
                (buttons and 0xFF).toByte(), ((buttons shr 8) and 0xFF).toByte(), (hat and 0x0F).toByte(),
                lx.coerceIn(0, 255).toByte(), ly.coerceIn(0, 255).toByte(),
                rx.coerceIn(0, 255).toByte(), ry.coerceIn(0, 255).toByte()
            ))
        }
    }

    fun stats(): String = "profil ${profileName()}, gamepad gönderilen $okCnt, hata $failCnt, bağlı: ${if (host != null) "evet" else "hayır"}"

    private var mediaFree = 0L

    /** Ses/medya tuşları: 1 = ses +, 2 = ses -, 4 = sessiz, 8 = oynat/duraklat */
    fun media(bits: Int) {
        q.post {
            val h = host ?: return@post
            val now = SystemClock.uptimeMillis()
            val t = maxOf(now, mediaFree)
            mediaFree = t + 70
            q.postDelayed({ hid?.sendReport(h, 2, byteArrayOf(bits.toByte())) }, t - now)
            q.postDelayed({ hid?.sendReport(h, 2, byteArrayOf(0)) }, t - now + 35)
        }
    }

    companion object {
        private const val MIN_HOLD = 40L
        private fun b(vararg v: Int): ByteArray = ByteArray(v.size) { v[it].toByte() }

        // Rapor 1: normal klavye (6 tuş)
        private val KB1 = b(
            0x05, 0x01, 0x09, 0x06, 0xA1, 0x01, 0x85, 0x01,
            0x05, 0x07, 0x19, 0xE0, 0x29, 0xE7, 0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x08, 0x81, 0x02,
            0x95, 0x01, 0x75, 0x08, 0x81, 0x01,
            0x95, 0x06, 0x75, 0x08, 0x15, 0x00, 0x25, 0x65, 0x05, 0x07, 0x19, 0x00, 0x29, 0x65, 0x81, 0x00,
            0xC0
        )
        // Rapor 2: ses / medya tuşları
        private val CONS = b(
            0x05, 0x0C, 0x09, 0x01, 0xA1, 0x01, 0x85, 0x02,
            0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x04,
            0x09, 0xE9, 0x09, 0xEA, 0x09, 0xE2, 0x09, 0xCD, 0x81, 0x02,
            0x95, 0x04, 0x81, 0x01,
            0xC0
        )
        // Rapor 3: oyun klavyesi (bitmap, 6'dan fazla tuş)
        private val NKRO = b(
            0x05, 0x01, 0x09, 0x06, 0xA1, 0x01, 0x85, 0x03,
            0x05, 0x07, 0x19, 0xE0, 0x29, 0xE7, 0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x08, 0x81, 0x02,
            0x05, 0x07, 0x19, 0x00, 0x29, 0x77, 0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x78, 0x81, 0x02,
            0xC0
        )
        // Rapor 5: gamepad (16 tuş, yön tuşu, 2 joystick)
        private val PAD = b(
            0x05, 0x01, 0x09, 0x05, 0xA1, 0x01, 0x85, 0x05,
            0x05, 0x09, 0x19, 0x01, 0x29, 0x10, 0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x10, 0x81, 0x02,
            0x05, 0x01, 0x09, 0x39, 0x15, 0x00, 0x25, 0x07, 0x35, 0x00, 0x46, 0x3B, 0x01, 0x65, 0x14, 0x75, 0x04, 0x95, 0x01, 0x81, 0x42,
            0x75, 0x04, 0x95, 0x01, 0x81, 0x01,
            0x05, 0x01, 0x09, 0x30, 0x09, 0x31, 0x09, 0x32, 0x09, 0x35, 0x15, 0x00, 0x26, 0xFF, 0x00, 0x75, 0x08, 0x95, 0x04, 0x81, 0x02,
            0xC0
        )

        /** 0 = hepsi, 1 = klavye + ses, 2 = sadece gamepad, 3 = sadece klavye, 4 = sadece gamepad (alternatif tür) */
        private fun desc(p: Int): ByteArray = when (p) {
            1 -> KB1 + CONS
            2, 4 -> PAD
            3 -> KB1
            else -> KB1 + CONS + NKRO + PAD
        }
    }
}
